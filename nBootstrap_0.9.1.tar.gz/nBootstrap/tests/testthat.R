library(testthat)
library(nBootstrap)

test_check("nBootstrap")
