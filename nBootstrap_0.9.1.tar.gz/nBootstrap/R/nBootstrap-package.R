#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title nBootstrap: Nonparametric Bootstrap
#'
#' @description A collection of functions
#'   related to the nonparametric bootstrap.
#'
#' @docType package
#' @name nBootstrap
#' @keywords nBootstrap package
NULL
